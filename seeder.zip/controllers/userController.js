import userModel from "../models/userModel.js";

//login controller
export const loginController = async (req, res) => {
  try {
    const { userId, password } = req.body;
    const user = await userModel.findOne({
      userId,
      password,
      verified: false,
    });
    if (user) {
      res.status(200).send({
        success: true,
        message: "Login successfully",
        user,
      });
    } else {
      res.json({
        success: false,
        message: "login fail",
        user,
      });
    }
  } catch (error) {
    console.log("Error in get Items");
  }
};

//register controller
export const registerController = async (req, res) => {
  try {
    const newUser = new userModel({ ...req.body, verified: true });
    await newUser.save();
    res.status(200).send("New user added successfully");
  } catch (error) {
    res.status(400).send(error);
    console.log(error);
  }
};
