import itemModel from "../models/itemModel.js";

export const getItemController = async (req, res) => {
  try {
    const items = await itemModel.find();
    res.status(200).send(items);
  } catch (error) {
    console.log("Error in get Items");
  }
};

//add item route
export const addItemController = async (req, res) => {
  try {
    const newItem = new itemModel(req.body);
    await newItem.save();
    res.status(200).send("Item created successfully");
  } catch (error) {
    res.status(400).send(error);
    console.log(error);
  }
};

//edit-item controller
export const editItemController = async (req, res) => {
  try {
    const { itemId } = req.body;
    await itemModel.findOneAndUpdate({ _id: req.body.itemId }, req.body);
    res.status(201).send({
      success: true,
      message: "Item Updated successfully",
    });
  } catch (error) {
    res.status(400).send({
      success: false,
      message: "Error while update",
      error,
    });
  }
};

// delete item controller
export const deleteItemController = async (req, res) => {
  try {
    const { itemId } = req.body;
    await itemModel.findOneAndDelete({ _id: itemId });
    res.status(200).json("item deleted");
  } catch (error) {
    res.status(500).send(error);
    console.log(error);
  }
};
