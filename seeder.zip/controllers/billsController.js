import billsModel from "../models/billsModel.js";

//add bills controller
export const addBillsController = async (req, res) => {
  try {
    const newBill = new billsModel(req.body);
    await newBill.save();
    res.status(200).send("Bill created successfully");
  } catch (error) {
    res.status(400).send(error);
    console.log(error);
  }
};

//get bills controller
export const getBillsController = async (req, res) => {
  try {
    const bills = await billsModel.find();
    res.status(200).send(bills);
  } catch (error) {
    console.log(bills);
  }
};
