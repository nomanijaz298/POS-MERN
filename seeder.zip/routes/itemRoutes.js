import express from "express";
import {
  addItemController,
  deleteItemController,
  editItemController,
  getItemController,
} from "../controllers/itemController.js";

const router = express.Router();

//routes
//get method
router.get("/get-item", getItemController);

//post method
router.post("/add-item", addItemController);

//put method
router.put("/edit-item", editItemController);

//method delete
router.post("/delete-item", deleteItemController);
export default router;
