import express from "express";

import {
  loginController,
  registerController,
} from "../controllers/userController.js";

const router = express.Router();

//routes
//get method
router.post("/login", loginController);

//post method
router.post("/register", registerController);

export default router;
