export const items = [
  {
    name: "Tea",
    price: 1,
    category: "drinks",
    image:
      "https://img.etimg.com/photo/msid-69212931,quality-100/chai-itself-was-once-a-trend-that-developed-this-way-.jpg",
  },
  {
    name: "coffee",
    price: 2,
    category: "drinks",
    image: "https://i.cdn.newsbytesapp.com/images/l110_14211532861690.jpg",
  },
  {
    name: "Chicken Biryani",
    price: 10,
    category: "rice",
    image:
      "https://www.licious.in/blog/wp-content/uploads/2020/12/Hyderabadi-chicken-Biryani.jpg",
  },
  {
    name: "Veg Biryani",
    price: 5,
    category: "rice",
    image:
      "https://www.indianveggiedelight.com/wp-content/uploads/2020/04/veg-biryani-instant-pot-featured.jpg",
  },
  {
    name: "Chicken Hakka",
    price: 7,
    category: "noodles",
    image: "https://cravecookclick.com/wp-content/uploads/2012/07/IMG_4400.jpg",
  },
  {
    name: "Eggy",
    price: 5,
    category: "noodles",
    image:
      "https://www.licious.in/blog/wp-content/uploads/2020/12/Egg-Noodles-min.jpg",
  },
];
