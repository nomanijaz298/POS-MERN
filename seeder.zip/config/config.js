import mongoose from "mongoose";
import colors from "colors";

//data base connection

export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URL);
    console.log(
      `Database connected Successfully ${conn.connection.host}`.bgGreen
    );
  } catch (error) {
    console.log(`Error in data base connection`.bgRed);
  }
};
